=== Indie Lane ===
A custom WordPress block theme for Indie Lane Photography (Donna Nugent).

WHY THIS THEME EXISTS
Static HTML converted to a WordPress theme usually becomes un-editable because the
content is hardcoded into PHP template files. The WordPress editor edits database
content, not template files, so there is nothing to click. This theme avoids that
trap entirely: it is a BLOCK THEME. Every section, heading, paragraph, button and
photo is a native WordPress block. The owner edits everything with click-to-edit
and drag-to-reorder in the standard editor. No Elementor, no licences, nothing to
break.

REQUIREMENTS
- WordPress 6.4 or newer
- PHP 7.4 or newer

SETUP (about 4 minutes)
1. Upload and activate the theme (Appearance > Themes > Add New > Upload Theme).
2. Create a new Page called "Home".
3. In that page, open the block inserter, go to the "Indie Lane" tab under Patterns,
   and insert "Indie Lane: Full homepage".
4. Settings > Reading > set "Your homepage displays" to a static page, choose "Home".
5. Appearance > Editor > Navigation to set the menu items (Work, Services, About,
   Client Gallery, Contact).

EDITING (for Donna)
- Click any text and type.
- Click any photo, then Replace, to swap it from the Media Library.
- Use the gallery block toolbar to add or remove portfolio photos.
- Drag any block by its toolbar handle to reorder sections, cards or photos.
- Press Update to publish.

RECOMMENDED PLUGINS
- Fluent Forms or WPForms for the enquiry form (wire it to hello@indielane.com.au).
- Pic-Time or Pixieset for the private client gallery (link from "Access your gallery").

IMAGES
The pattern references Donna's existing photos from her current site so it looks
right immediately. Re-upload final images into the Media Library before go-live.

This theme is released under GPL v2 or later.
