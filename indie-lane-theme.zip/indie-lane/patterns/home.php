<?php
/**
 * Title: Indie Lane: Full homepage
 * Slug: indie-lane/homepage
 * Categories: indie-lane
 * Block Types: core/post-content
 * Description: The complete Indie Lane homepage. Insert it into your Home page, then click any text or photo to edit, or drag any block to reorder.
 */
?>
<!-- wp:cover {"url":"https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1694661510748-0WSGN36LKWAJQNA3EQ6P/Nikki_Soul+Potter_June+2023_by+Donna_Indie+Lane_LR-66_All.jpg?format=2000w","dimRatio":55,"overlayColor":"deep","minHeight":88,"minHeightUnit":"vh","align":"full","className":"il-hero","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull il-hero"><span aria-hidden="true" class="wp-block-cover__background has-deep-background-color has-background-dim-60 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Natural light branding portrait by Indie Lane Photography in the Byron Bay region" src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1694661510748-0WSGN36LKWAJQNA3EQ6P/Nikki_Soul+Potter_June+2023_by+Donna_Indie+Lane_LR-66_All.jpg?format=2000w" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:paragraph {"className":"il-hero-eyebrow"} -->
<p class="il-hero-eyebrow">Byron Bay · Northern NSW · Gold Coast</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"className":"il-hero-title"} -->
<h1 class="il-hero-title">Photography that captures the real you, in <em>natural light</em></h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"il-hero-sub"} -->
<p class="il-hero-sub">Indie Lane is the work of Donna Nugent, a branding, commercial and lifestyle photographer now based in the Byron Bay region. Relaxed sessions, vibrant colour and storytelling images your business and your family will love.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#book">Book your shoot</a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#work">View the portfolio</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover -->

<!-- wp:group {"anchor":"about","className":"il-section il-reveal","layout":{"type":"constrained"}} -->
<div class="wp-block-group il-section il-reveal" id="about"><!-- wp:columns {"verticalAlignment":"center","className":"il-split"} -->
<div class="wp-block-columns are-vertically-aligned-center il-split"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"className":"il-eyebrow"} -->
<p class="il-eyebrow">Meet Donna</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"className":"il-headline"} -->
<h2 class="wp-block-heading il-headline">A calm, personable approach that puts you at ease</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"il-body"} -->
<p class="il-body">Most people tell me they hate being in front of a camera. That is exactly where I love to start. I take the time to get to know you and your vision, then create a relaxed space where you can be yourself and have a little fun.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"il-body"} -->
<p class="il-body">The result is honest, vibrant images that actually look like you. After years on the Surf Coast in Victoria, I have moved to the Byron Bay region and I now photograph clients across Northern NSW, Tweed Heads and the Gold Coast, with regular trips back to Victoria.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"24px"}}}} -->
<div class="wp-block-buttons" style="margin-top:24px"><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#book">Work with Donna</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1589958484832-0BZL0V30GUDHQK3GSDE8/Renault-Donna-7.jpg?format=1200w" alt="Donna Nugent, photographer and owner of Indie Lane Photography"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"services","className":"il-section il-alt il-reveal","layout":{"type":"constrained"}} -->
<div class="wp-block-group il-section il-alt il-reveal" id="services"><!-- wp:paragraph {"className":"il-eyebrow"} -->
<p class="il-eyebrow">What I photograph</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"className":"il-headline"} -->
<h2 class="wp-block-heading il-headline">Sessions made for your brand and your people</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"il-body","style":{"spacing":{"margin":{"bottom":"40px"}}}} -->
<p class="il-body" style="margin-bottom:40px">Every shoot is relaxed, unhurried and built around what you actually need the images for. Here is where I can help.</p>
<!-- /wp:paragraph -->
<!-- wp:group {"className":"il-services-grid","layout":{"type":"default"}} -->
<div class="wp-block-group il-services-grid">

<!-- wp:group {"className":"il-service-card","layout":{"type":"default"}} -->
<div class="wp-block-group il-service-card"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1589956102242-3IG4BG01IZC2IF3W8DDC/Rowena+Martinich_Aug+2018_Indie+Lane_LR_15.JPG?format=900w" alt="Branding portrait session by Indie Lane"/></figure>
<!-- /wp:image -->
<!-- wp:group {"className":"il-card-body","layout":{"type":"default"}} -->
<div class="wp-block-group il-card-body"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Branding Portraits</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Headshots and personal brand images that look like you, not a stiff corporate suit. Perfect for your website, LinkedIn and socials.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"il-service-card","layout":{"type":"default"}} -->
<div class="wp-block-group il-service-card"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1589955861954-VUA28FI6S1VS24SBJQKI/GLC_Newtown_Feb+2019_by+Indie+Lane_LR-45.jpg?format=900w" alt="Commercial photography for business by Indie Lane"/></figure>
<!-- /wp:image -->
<!-- wp:group {"className":"il-card-body","layout":{"type":"default"}} -->
<div class="wp-block-group il-card-body"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Commercial</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Documentary style photography for businesses, schools and councils. People, products and spaces, captured with an artistic eye.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"il-service-card","layout":{"type":"default"}} -->
<div class="wp-block-group il-service-card"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1579489757515-J2O2G1ISF3EPAXFE0O61/Shaun_Nature+HC_Indie+Lane_LR_25.JPG?format=900w" alt="Lifestyle and family photography by Indie Lane"/></figure>
<!-- /wp:image -->
<!-- wp:group {"className":"il-card-body","layout":{"type":"default"}} -->
<div class="wp-block-group il-card-body"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Lifestyle &amp; Family</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Relaxed lifestyle sessions full of happy faces and real moments, shot outdoors in beautiful natural light.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"il-service-card","layout":{"type":"default"}} -->
<div class="wp-block-group il-service-card"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1694661562955-X2SREZJ8INNJB3YSY0CC/Manuko_Torquay_June+2023_by+Donna_Indie+Lane_LR-10.jpg?format=900w" alt="Food and product photography by Indie Lane"/></figure>
<!-- /wp:image -->
<!-- wp:group {"className":"il-card-body","layout":{"type":"default"}} -->
<div class="wp-block-group il-card-body"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Food &amp; Product</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Fresh, vibrant images that make your menu and products irresistible, online and in print.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"il-service-card","layout":{"type":"default"}} -->
<div class="wp-block-group il-service-card"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1694588579515-80X65R9NYIHW3Y1UZOY2/Nikki_Soul+Potter_June+2023_by+Donna_Indie+Lane_LR-24-Edit.jpg?format=900w" alt="Editorial photography by Indie Lane"/></figure>
<!-- /wp:image -->
<!-- wp:group {"className":"il-card-body","layout":{"type":"default"}} -->
<div class="wp-block-group il-card-body"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Editorial</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Storytelling image sets for magazines, features and campaigns, with a strong natural light feel.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"il-service-card","layout":{"type":"default"}} -->
<div class="wp-block-group il-service-card"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1579584574076-WE61NTS9O6AHTSYCFYTI/Jo+Surkitt_June+2018_Indie+Lane_HR_64.JPG?format=900w" alt="Events photography by Indie Lane"/></figure>
<!-- /wp:image -->
<!-- wp:group {"className":"il-card-body","layout":{"type":"default"}} -->
<div class="wp-block-group il-card-body"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Events</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Natural, candid coverage that captures the feeling of the day, from launches to celebrations.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

</div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:cover {"url":"https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1694661858760-MR5RRQSSV7KJ3ALIATP4/Manuko_Torquay_June+2023_by+Donna_Indie+Lane_LR-15.jpg?format=1800w","dimRatio":40,"overlayColor":"deep","minHeight":56,"minHeightUnit":"vh","align":"full","className":"il-fullbleed","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull il-fullbleed"><span aria-hidden="true" class="wp-block-cover__background has-deep-background-color has-background-dim-40 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Storytelling lifestyle photography by Indie Lane" src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1694661858760-MR5RRQSSV7KJ3ALIATP4/Manuko_Torquay_June+2023_by+Donna_Indie+Lane_LR-15.jpg?format=1800w" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:paragraph {"align":"center","className":"il-fullbleed-quote"} -->
<p class="has-text-align-center il-fullbleed-quote">Storytelling, happy faces, vibrant colours and natural light.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

<!-- wp:group {"anchor":"work","className":"il-section il-portfolio il-reveal","layout":{"type":"constrained"}} -->
<div class="wp-block-group il-section il-portfolio il-reveal" id="work"><!-- wp:paragraph {"className":"il-eyebrow"} -->
<p class="il-eyebrow">Portfolio</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"className":"il-headline","style":{"spacing":{"margin":{"bottom":"36px"}}}} -->
<h2 class="wp-block-heading il-headline" style="margin-bottom:36px">A look at recent work</h2>
<!-- /wp:heading -->
<!-- wp:gallery {"columns":3,"linkTo":"none","className":"il-portfolio-gallery"} -->
<figure class="wp-block-gallery has-nested-images columns-3 is-cropped il-portfolio-gallery">
<!-- wp:image {"linkDestination":"none"} --><figure class="wp-block-image"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1579489775343-A8KFNSA8LKNV6R6Z2TPH/Chela+Edmunds_Takeawei_by+Indie+Lane_LR.JPG-85.JPG?format=800w" alt="Indie Lane portfolio image"/></figure><!-- /wp:image -->
<!-- wp:image {"linkDestination":"none"} --><figure class="wp-block-image"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1579659540411-5F9UHKKPTUJSBC0T76QZ/Lauren+Barton_Indie+Lane_LR_33.JPG?format=800w" alt="Indie Lane portfolio image"/></figure><!-- /wp:image -->
<!-- wp:image {"linkDestination":"none"} --><figure class="wp-block-image"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1694661446257-PJCW90GU122HTGH2DEC1/Nikki_Soul+Potter_June+2023_by+Donna_Indie+Lane_LR-30_All.jpg?format=800w" alt="Indie Lane portfolio image"/></figure><!-- /wp:image -->
<!-- wp:image {"linkDestination":"none"} --><figure class="wp-block-image"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1579584575330-LLGP0JUCXMHR6SY2X717/Leanne+Rowbottom_May+2019_by+Indie+Lane_LR-137.jpg?format=800w" alt="Indie Lane portfolio image"/></figure><!-- /wp:image -->
<!-- wp:image {"linkDestination":"none"} --><figure class="wp-block-image"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1580879219994-IFVR4R6VZESOX2QE1UJQ/Chela+Edmunds_Takeawei_by+Indie+Lane_LR.JPG-71.JPG?format=800w" alt="Indie Lane portfolio image"/></figure><!-- /wp:image -->
<!-- wp:image {"linkDestination":"none"} --><figure class="wp-block-image"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1694661860046-UGWNHVDAGGWKW74K9458/Manuko_Torquay_June+2023_by+Donna_Indie+Lane_LR-61.jpg?format=800w" alt="Indie Lane portfolio image"/></figure><!-- /wp:image -->
<!-- wp:image {"linkDestination":"none"} --><figure class="wp-block-image"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1579584574076-WE61NTS9O6AHTSYCFYTI/Jo+Surkitt_June+2018_Indie+Lane_HR_64.JPG?format=800w" alt="Indie Lane portfolio image"/></figure><!-- /wp:image -->
<!-- wp:image {"linkDestination":"none"} --><figure class="wp-block-image"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1694662030490-GPNZCR4U7RUVQS7D3G8F/Manuko_Torquay_June+2023_by+Donna_Indie+Lane_LR-74.jpg?format=800w" alt="Indie Lane portfolio image"/></figure><!-- /wp:image -->
<!-- wp:image {"linkDestination":"none"} --><figure class="wp-block-image"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1589955861954-VUA28FI6S1VS24SBJQKI/GLC_Newtown_Feb+2019_by+Indie+Lane_LR-45.jpg?format=800w" alt="Indie Lane portfolio image"/></figure><!-- /wp:image -->
</figure>
<!-- /wp:gallery --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"il-section il-deep il-reveal","layout":{"type":"constrained"}} -->
<div class="wp-block-group il-section il-deep il-reveal"><!-- wp:paragraph {"className":"il-eyebrow"} -->
<p class="il-eyebrow">Why Indie Lane</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"className":"il-headline","style":{"spacing":{"margin":{"bottom":"40px"}}}} -->
<h2 class="wp-block-heading il-headline" style="margin-bottom:40px">Photography that feels easy and looks like you</h2>
<!-- /wp:heading -->
<!-- wp:group {"className":"il-values","layout":{"type":"default"}} -->
<div class="wp-block-group il-values">
<!-- wp:group {"className":"il-value","layout":{"type":"default"}} -->
<div class="wp-block-group il-value"><!-- wp:paragraph {"className":"il-num"} --><p class="il-num">01</p><!-- /wp:paragraph -->
<!-- wp:heading {"level":4} --><h4 class="wp-block-heading">Natural light specialist</h4><!-- /wp:heading -->
<!-- wp:paragraph --><p>Soft, true to life images with the warmth and colour the coast is known for.</p><!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"il-value","layout":{"type":"default"}} -->
<div class="wp-block-group il-value"><!-- wp:paragraph {"className":"il-num"} --><p class="il-num">02</p><!-- /wp:paragraph -->
<!-- wp:heading {"level":4} --><h4 class="wp-block-heading">A relaxed experience</h4><!-- /wp:heading -->
<!-- wp:paragraph --><p>A calm, friendly approach so even camera shy clients feel comfortable.</p><!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"il-value","layout":{"type":"default"}} -->
<div class="wp-block-group il-value"><!-- wp:paragraph {"className":"il-num"} --><p class="il-num">03</p><!-- /wp:paragraph -->
<!-- wp:heading {"level":4} --><h4 class="wp-block-heading">Images that convert</h4><!-- /wp:heading -->
<!-- wp:paragraph --><p>Photos built to work hard on your website, socials and marketing.</p><!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"il-value","layout":{"type":"default"}} -->
<div class="wp-block-group il-value"><!-- wp:paragraph {"className":"il-num"} --><p class="il-num">04</p><!-- /wp:paragraph -->
<!-- wp:heading {"level":4} --><h4 class="wp-block-heading">Byron region and VIC</h4><!-- /wp:heading -->
<!-- wp:paragraph --><p>Based in the Byron Bay region, with regular shoots back in Victoria.</p><!-- /wp:paragraph --></div>
<!-- /wp:group -->
</div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"il-section il-alt il-reveal","layout":{"type":"constrained"}} -->
<div class="wp-block-group il-section il-alt il-reveal"><!-- wp:paragraph {"className":"il-eyebrow"} -->
<p class="il-eyebrow">Kind words</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"className":"il-headline"} -->
<h2 class="wp-block-heading il-headline">Loved by the people in front of the lens</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"small","style":{"typography":{"fontStyle":"italic"},"spacing":{"margin":{"bottom":"40px"}}}} -->
<p class="has-small-font-size" style="font-style:italic;margin-bottom:40px">Sample reviews. Swap these for real client quotes any time.</p>
<!-- /wp:paragraph -->
<!-- wp:group {"className":"il-testi-grid","layout":{"type":"default"}} -->
<div class="wp-block-group il-testi-grid">
<!-- wp:group {"className":"il-testi","layout":{"type":"default"}} -->
<div class="wp-block-group il-testi"><!-- wp:paragraph {"className":"il-stars"} --><p class="il-stars">★★★★★</p><!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"il-quote"} --><p class="il-quote">Donna made me feel so at ease. I usually freeze in photos, but these actually look like me.</p><!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"il-cite"} --><p class="il-cite">Sarah M. · Branding client</p><!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"il-testi","layout":{"type":"default"}} -->
<div class="wp-block-group il-testi"><!-- wp:paragraph {"className":"il-stars"} --><p class="il-stars">★★★★★</p><!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"il-quote"} --><p class="il-quote">Our team headshots have never looked this good. We are already booking again next year.</p><!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"il-cite"} --><p class="il-cite">James T. · Business owner</p><!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:group {"className":"il-testi","layout":{"type":"default"}} -->
<div class="wp-block-group il-testi"><!-- wp:paragraph {"className":"il-stars"} --><p class="il-stars">★★★★★</p><!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"il-quote"} --><p class="il-quote">Beautiful, vibrant images that captured our brand and our food perfectly.</p><!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"il-cite"} --><p class="il-cite">Kel R. · Cafe owner</p><!-- /wp:paragraph --></div>
<!-- /wp:group -->
</div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"clients","className":"il-section il-reveal","layout":{"type":"constrained"}} -->
<div class="wp-block-group il-section il-reveal" id="clients"><!-- wp:columns {"verticalAlignment":"center","className":"il-split"} -->
<div class="wp-block-columns are-vertically-aligned-center il-split"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"className":"il-eyebrow"} -->
<p class="il-eyebrow">Existing clients</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"className":"il-headline"} -->
<h2 class="wp-block-heading il-headline">Your private gallery, ready when you are</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"il-body"} -->
<p class="il-body">Already had a shoot with Indie Lane? Log in to view, download and share your high resolution images any time, from any device.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"24px"}}}} -->
<div class="wp-block-buttons" style="margin-top:24px"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Access your gallery</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1579584570564-OPB0HLNJJ7MGP5W5RD4F/Claire+Summers_March+2019_by+Indie+Lane_LR-99.jpg?format=1100w" alt="Client viewing their private online photo gallery from Indie Lane"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"anchor":"book","className":"il-section il-deep il-reveal","layout":{"type":"constrained"}} -->
<div class="wp-block-group il-section il-deep il-reveal" id="book"><!-- wp:columns {"className":"il-split"} -->
<div class="wp-block-columns il-split"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"il-eyebrow"} -->
<p class="il-eyebrow">Book a shoot</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"className":"il-headline"} -->
<h2 class="wp-block-heading il-headline">Let's create your visual story</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"il-body","style":{"spacing":{"margin":{"bottom":"28px"}}}} -->
<p class="il-body" style="margin-bottom:28px">Tell me a little about what you need and I will get back to you within one business day with availability and pricing.</p>
<!-- /wp:paragraph -->
<!-- wp:html -->
<div class="il-form">
<form>
<label>First name</label><input type="text" name="name" placeholder="Your name" required />
<label>Email</label><input type="email" name="email" placeholder="you@email.com" required />
<label>Phone</label><input type="tel" name="phone" placeholder="0400 000 000" />
<label>What are you after?</label>
<select name="type"><option>Branding Portraits</option><option>Commercial</option><option>Lifestyle &amp; Family</option><option>Food &amp; Product</option><option>Editorial</option><option>Event</option><option>Something else</option></select>
<label>Tell me about your shoot</label><textarea name="message" rows="4" placeholder="Location, dates, what the images are for..."></textarea>
<button type="submit" class="wp-block-button__link">Send enquiry</button>
</form>
<div class="il-form-success" style="display:none;padding:20px;border:1px solid #B0764F;background:rgba(176,118,79,0.12);color:#F3ECE1;border-radius:4px;">Thank you. Your enquiry has been sent and Donna will be in touch within one business day.</div>
</div>
<!-- /wp:html --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"il-eyebrow"} -->
<p class="il-eyebrow">Call or text</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">0400 815 182</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"il-eyebrow","style":{"spacing":{"margin":{"top":"24px"}}}} -->
<p class="il-eyebrow" style="margin-top:24px">Email</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">hello@indielane.com.au</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"il-eyebrow","style":{"spacing":{"margin":{"top":"24px"}}}} -->
<p class="il-eyebrow" style="margin-top:24px">Servicing</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"il-body"} -->
<p class="il-body">Byron Bay, Northern NSW, Tweed Heads, Gold Coast, plus Victoria.</p>
<!-- /wp:paragraph -->
<!-- wp:image {"sizeSlug":"large","linkDestination":"none","style":{"spacing":{"margin":{"top":"24px"}}}} -->
<figure class="wp-block-image size-large" style="margin-top:24px"><img src="https://images.squarespace-cdn.com/content/v1/5de9b2b9fb7f953b5154014b/1694588672723-NH1KVIHBCE3WWIHNPZ76/Maria_Portraits_Jan%2B2021_by%2BDonna_Indie%2BLane_LR-20.jpg?format=1000w" alt="Portrait photography session with Indie Lane"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
