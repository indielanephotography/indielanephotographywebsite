<?php
/**
 * Indie Lane theme functions.
 *
 * @package indie-lane
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'indie_lane_setup' ) ) {
	function indie_lane_setup() {
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'editor-styles' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'html5', array( 'style', 'script', 'navigation-widgets' ) );

		// Load the same design stylesheet inside the editor so it matches the front end.
		add_editor_style( 'style.css' );
		add_editor_style( 'assets/css/fonts.css' );
	}
}
add_action( 'after_setup_theme', 'indie_lane_setup' );

/**
 * Front-end assets.
 */
function indie_lane_assets() {
	// Google Fonts.
	wp_enqueue_style(
		'indie-lane-fonts',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=Montserrat:wght@300;400;500;600&display=swap',
		array(),
		null
	);

	// Theme design stylesheet.
	wp_enqueue_style(
		'indie-lane-style',
		get_stylesheet_uri(),
		array( 'indie-lane-fonts' ),
		wp_get_theme()->get( 'Version' )
	);

	// Animations, sticky bar, demo form handling.
	wp_enqueue_script(
		'indie-lane-script',
		get_theme_file_uri( 'assets/js/indie-lane.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'indie_lane_assets' );

/**
 * Make the Google Fonts available inside the block editor too.
 */
function indie_lane_editor_fonts() {
	wp_enqueue_style(
		'indie-lane-editor-fonts',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=Montserrat:wght@300;400;500;600&display=swap',
		array(),
		null
	);
}
add_action( 'enqueue_block_assets', 'indie_lane_editor_fonts' );

/**
 * Register a pattern category so Donna can find the ready-made sections
 * under a clear "Indie Lane" tab in the block inserter.
 */
function indie_lane_pattern_category() {
	if ( function_exists( 'register_block_pattern_category' ) ) {
		register_block_pattern_category(
			'indie-lane',
			array( 'label' => __( 'Indie Lane', 'indie-lane' ) )
		);
	}
}
add_action( 'init', 'indie_lane_pattern_category' );
