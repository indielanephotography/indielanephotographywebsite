/* Indie Lane theme: light front-end interactions. */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    document.documentElement.classList.add('il-js');
    // Scroll reveal for sections marked with .il-reveal.
    var reveals = document.querySelectorAll('.il-reveal');
    if ('IntersectionObserver' in window && reveals.length) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) {
            en.target.classList.add('il-visible');
            io.unobserve(en.target);
          }
        });
      }, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });
      reveals.forEach(function (el) { io.observe(el); });
    } else {
      reveals.forEach(function (el) { el.classList.add('il-visible'); });
    }

    // Sticky mobile CTA bar.
    var bar = document.querySelector('.il-sticky-bar');
    if (bar) {
      var threshold = window.innerHeight * 1.2;
      window.addEventListener('scroll', function () {
        bar.classList.toggle('il-visible', window.scrollY > threshold);
      }, { passive: true });
    }

    // Demo enquiry form (shows a thank-you without a backend).
    // Replace with Fluent Forms / WPForms for live lead capture.
    var form = document.querySelector('.il-form form');
    if (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var ok = document.querySelector('.il-form-success');
        form.style.display = 'none';
        if (ok) { ok.style.display = 'block'; }
      });
    }
  });
})();
